package calculadora.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	private Button btn1, btn2, btn3, btn4,btn5,btn6,btn7,btn8,btn9,btn0;
	private Button btnC,btnRes,btnMulti,btnSubtrair,btnSomar,btnDividir;
	private TextView campNum;
	private double valor1 = 0, valor2 = 0;
	private double resultado;
	private String operador = ""; 
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		btn0 = findViewById(R.id.btn0);
		btn1 = findViewById(R.id.btn1);
		btn2 = findViewById(R.id.btn2);
		btn3 = findViewById(R.id.btn3);
		btn4 = findViewById(R.id.btn4);
		btn5 = findViewById(R.id.btn5);
		btn6 = findViewById(R.id.btn6);
		btn7 = findViewById(R.id.btn7);
		btn8 = findViewById(R.id.btn8);
		btn9 = findViewById(R.id.btn9);
		
		btnC = findViewById(R.id.btnC);
		btnMulti = findViewById(R.id.btnMultiplicar);
		btnSomar = findViewById(R.id.btnSomar);
		btnDividir = findViewById(R.id.btnDividir);
		btnSubtrair = findViewById(R.id.btnSubtrair);
		btnRes = findViewById(R.id.btnRes);
		
		campNum = findViewById(R.id.campoNum);
		
		View.OnClickListener listenerNumero = v ->  {
			Button b = (Button) v;
			campNum.append(b.getText());
		};
		
		btn0.setOnClickListener(listenerNumero);
		btn1.setOnClickListener(listenerNumero);
		btn2.setOnClickListener(listenerNumero);
		btn3.setOnClickListener(listenerNumero);
		btn4.setOnClickListener(listenerNumero);
		btn5.setOnClickListener(listenerNumero);
		btn6.setOnClickListener(listenerNumero);
		btn7.setOnClickListener(listenerNumero);
		btn8.setOnClickListener(listenerNumero);
		btn9.setOnClickListener(listenerNumero);
		
		btnSomar.setOnClickListener(v -> operar("+"));
		btnDividir.setOnClickListener(v -> operar("/"));
		btnMulti.setOnClickListener(v -> operar("*"));
		btnSubtrair.setOnClickListener(v -> operar("-"));
		
		btnRes.setOnClickListener(v -> calcular());
		btnC.setOnClickListener(v -> limpar());
    }
	public void operar(String op){
		try {
			valor1 = Double.parseDouble(campNum.getText().toString());
			operador = op;
			campNum.setText("");
		}catch(NumberFormatException e){
			campNum.setText("Erro");
		}
	}
	
	public void calcular(){
		try{
			valor2 = Double.parseDouble(campNum.getText().toString());
			resultado = 0;
			
			switch(operador){
				case "+":
				 resultado = valor1 + valor2;
				 break;
				 
				 case "*":
				 resultado = valor1 * valor2;
				 break;
				 
				 case "-":
				 resultado = valor1 - valor2;
				 break;
				 
				 case "/":
				 if(valor2 != 0){
				 resultado = valor1 + valor2;
				 }else{
					 campNum.setText("erro");
				 }
				 break;
			}
			campNum.setText(String.valueOf(resultado));
		}catch(NumberFormatException e){
			campNum.setText("Erro");
		}
	}
	public void limpar(){
		valor1 =  0;
		valor2 = 0;
		campNum.setText("0");
	}
}